function ExternalAlert(){
    alert('This is Alert');
}
function ExternalConfirm(){
    if(confirm('Are you sure?...')){
        alert('YESS');
    }
    else{
        alert('NOO');
    }
}
function ExternalPrompt(){
    var fname=prompt('Enter your first name');
    var lname=prompt('Enter your last name');
    alert(fname+ " "+lname);
}